package umg.edu.test.EjercicioTree;


import java.util.*;
import java.time.*;

public class Ejercicio3 {
    public static void main(String[] args) {

        ZoneId guatemalaZone = ZoneId.of("America/Guatemala");

        TreeSet<Evento> eventos = new TreeSet<>();


        agregarEvento(eventos, "Taller de Machine Learning", LocalDateTime.of(2025, 4, 15, 14, 0), "Sala 3", guatemalaZone);
        agregarEvento(eventos, "Conferencia de Java", LocalDateTime.of(2025, 5, 10, 10, 0), "Auditorio A", guatemalaZone);

        // Agregar un evento pasado para probar la eliminación
        agregarEvento(eventos, "Evento Pasado", LocalDateTime.of(2024, 4, 10, 10, 0), "Sala 1", guatemalaZone);


        System.out.println("Próximo evento: " + obtenerProximoEvento(eventos));

        // Mostrar la lista de eventos ordenados cronológicamente
        System.out.println("\nLista de eventos:");
        mostrarEventos(eventos);

        // Eliminar el evento pasado
        eliminarEventoPasado(eventos, guatemalaZone);
        System.out.println("\nEventos después de eliminar el pasado:");
        mostrarEventos(eventos);
    }

    // Método para agregar un evento
    public static void agregarEvento(TreeSet<Evento> eventos, String nombre, LocalDateTime fecha, String ubicacion, ZoneId zonaHoraria) {
        // Convertir la fecha a la zona horaria de Guatemala
        ZonedDateTime fechaConZona = fecha.atZone(zonaHoraria);
        Evento evento = new Evento(nombre, fechaConZona, ubicacion);
        eventos.add(evento);
        System.out.println("Evento agregado: " + evento);
    }

    // Método para obtener el próximo evento
    public static Evento obtenerProximoEvento(TreeSet<Evento> eventos) {
        return eventos.first();  // El primer evento en el TreeSet es el próximo evento
    }

    // Método para eliminar eventos pasados
    public static void eliminarEventoPasado(TreeSet<Evento> eventos, ZoneId zonaHoraria) {
        Iterator<Evento> iterator = eventos.iterator();
        ZonedDateTime ahora = ZonedDateTime.now(zonaHoraria);  // Fecha y hora actual en Guatemala
        while (iterator.hasNext()) {
            Evento evento = iterator.next();
            if (evento.getFecha().isBefore(ahora)) {
                iterator.remove();  // Elimina el evento pasado
                System.out.println("Evento pasado eliminado: " + evento);
            }
        }
    }

    // Método para mostrar todos los eventos
    public static void mostrarEventos(TreeSet<Evento> eventos) {
        int contador = 1;
        for (Evento evento : eventos) {
            // Mostrar solo la fecha y hora sin la zona horaria
            System.out.println(contador++ + ". " + evento);
        }
    }
}

// Clase Evento que implementa Comparable para ordenar por fecha
class Evento implements Comparable<Evento> {
    private String nombre;
    private ZonedDateTime fecha;  // Usar ZonedDateTime para incluir la zona horaria
    private String ubicacion;

    public Evento(String nombre, ZonedDateTime fecha, String ubicacion) {
        this.nombre = nombre;
        this.fecha = fecha;
        this.ubicacion = ubicacion;
    }

    public ZonedDateTime getFecha() {
        return fecha;
    }

    @Override
    public int compareTo(Evento otroEvento) {
        // Ordenamos los eventos por fecha
        return this.fecha.compareTo(otroEvento.fecha);
    }

    @Override
    public String toString() {
        // Mostrar solo la fecha y la hora sin la zona horaria
        return "\"" + nombre + "\", " + fecha.toLocalDateTime() + ", " + ubicacion;
    }
}

