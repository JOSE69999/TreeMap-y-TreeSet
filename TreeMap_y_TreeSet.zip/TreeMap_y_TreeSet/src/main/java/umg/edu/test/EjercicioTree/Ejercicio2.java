package umg.edu.test.EjercicioTree;

import java.util.*;

public class Ejercicio2 {
    public static void main(String[] args) {

        TreeMap<Integer, String> versiones = new TreeMap<>();

        // Agregar versiones
        agregarVersion(versiones, "System.out.println('Hola Mundo');");
        agregarVersion(versiones, "System.out.println('Hola Java');");


        System.out.println("Última versión: \"" + obtenerUltimaVersion(versiones) + "\"");

        // Obtener una versión específica
        int versionBuscada = 1;
        System.out.println("Versión " + versionBuscada + ": \"" + obtenerVersionEspecifica(versiones, versionBuscada) + "\"");

        // Eliminar una versión específica
        eliminarVersion(versiones, 1);
        System.out.println("Versión 1 eliminada.");

        // Mostrar el estado final del TreeMap de versiones
        System.out.println("\nVersiones restantes:");
        mostrarVersiones(versiones);
    }

    // Método para agregar una nueva versión
    public static void agregarVersion(TreeMap<Integer, String> versiones, String contenido) {
        int nuevaClave = versiones.size() + 1;  // La nueva clave será el tamaño actual del TreeMap + 1
        versiones.put(nuevaClave, contenido);
        System.out.println("Agregar versión " + nuevaClave + ": \"" + contenido + "\"");
    }

    // Método para obtener una versión específica
    public static String obtenerVersionEspecifica(TreeMap<Integer, String> versiones, int clave) {
        return versiones.getOrDefault(clave, "Versión no encontrada");
    }


    public static String obtenerUltimaVersion(TreeMap<Integer, String> versiones) {
        return versiones.lastEntry().getValue();
    }

    // Método para eliminar una versión específica
    public static void eliminarVersion(TreeMap<Integer, String> versiones, int clave) {
        if (versiones.containsKey(clave)) {
            versiones.remove(clave);
            System.out.println("Versión " + clave + " eliminada.");
        } else {
            System.out.println("No se encontró la versión " + clave + " para eliminar.");
        }
    }

    // Método para mostrar todas las versiones
    public static void mostrarVersiones(TreeMap<Integer, String> versiones) {
        for (Map.Entry<Integer, String> entry : versiones.entrySet()) {
            System.out.println("Versión " + entry.getKey() + ": \"" + entry.getValue() + "\"");
        }
    }

}