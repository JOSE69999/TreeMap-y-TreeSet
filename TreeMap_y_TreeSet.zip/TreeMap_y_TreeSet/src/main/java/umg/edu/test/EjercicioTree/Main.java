package umg.edu.test.EjercicioTree;

import java.io.*;
import java.util.*;

public class Main {
    public static void main(String[] args) {

        String rutaArchivo = "texto.txt";

        // Crear un TreeMap para almacenar las palabras y sus frecuencias
        TreeMap<String, Integer> frecuenciaPalabras = new TreeMap<>();

        try {

            BufferedReader reader = new BufferedReader(new FileReader(rutaArchivo));
            String linea;

            while ((linea = reader.readLine()) != null) {

                System.out.println("Linea leída: " + linea);

                // Convertir la línea a minúsculas y dividirla en palabras
                String[] palabras = linea.toLowerCase().split("\\W+");
                System.out.println("Palabras encontradas: " + Arrays.toString(palabras));

                for (String palabra : palabras) {
                    if (!palabra.isEmpty()) {
                        // Actualizar la frecuencia de cada palabra
                        frecuenciaPalabras.put(palabra, frecuenciaPalabras.getOrDefault(palabra, 0) + 1);
                        // Imprimir la frecuencia actual de la palabra
                        System.out.println("Frecuencia de '" + palabra + "': " + frecuenciaPalabras.get(palabra));
                    }
                }
            }
            reader.close();

            // Imprimir las palabras en orden alfabético junto con su frecuencia
            System.out.println("Frecuencia de palabras:");
            for (Map.Entry<String, Integer> entrada : frecuenciaPalabras.entrySet()) {
                System.out.println(entrada.getKey() + ": " + entrada.getValue());
            }

        } catch (IOException e) {
            System.out.println("Error al leer el archivo: " + e.getMessage());
        }
    }
}